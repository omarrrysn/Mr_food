const mainMenu ="https://mrfood225.000webhostapp.com/php/select/selectList.php";

const secondList=`https://mrfood225.000webhostapp.com/php/select/selectItems.php?id=`;

const subItem= `https://mrfood225.000webhostapp.com/php/select/subItems.php?id=`;

const insertMainMenu = 'https://mrfood225.000webhostapp.com/php/Insert/insertlist.php';

const insertItems='https://mrfood225.000webhostapp.com/php/insertItems.php';

const insertSubItems='https://mrfood225.000webhostapp.com/php/insertSubItems.php';

const insertUsers='https://mrfood225.000webhostapp.com/php/Insert/insertUsers.php';

const insertTables='https://mrfood225.000webhostapp.com/php/Insert/insertTables.php';

const insertOrderDetails='https://mrfood225.000webhostapp.com/php/Insert/insertOrderDetails.php'

const images=`https://mrfood225.000webhostapp.com/php/`;

const selectedRole='https://mrfood225.000webhostapp.com/php/select/selectedRoles.php';

const selectedUsers='https://mrfood225.000webhostapp.com/php/select/selectedUsers.php';

const selectchef= 'https://mrfood225.000webhostapp.com/php/select/selectChef.php';

const selectTables='https://mrfood225.000webhostapp.com/php/select/selectTables.php';

const selectManger='https://mrfood225.000webhostapp.com/php/select/SelectManger.php';

const deleteSecond = 'https://mrfood225.000webhostapp.com/php/delete/DeleteItem.php?id=';

const deleteThird = 'https://mrfood225.000webhostapp.com/php/delete/deleteThird.php?id=';

const LoginTables='https://mrfood225.000webhostapp.com/php/Login/LoginTables.php';

const LoginUser='https://mrfood225.000webhostapp.com/php/Users/Login.php';

const chefOrder=`https://mrfood225.000webhostapp.com/php/Users/OrderChef.php?chefId=`;

const OrderCashier='https://mrfood225.000webhostapp.com/php/Users/OrderCasher.php';

const updateOrderStatusChef='https://mrfood225.000webhostapp.com/php/Users/updateOrderStatusChef.php';

const updateStatus='https://mrfood225.000webhostapp.com/php/Users/updateStatus.php';

const insertMainOrder='https://mrfood225.000webhostapp.com/php/Insert/insertMainOrder.php';

const updateTotaleprice='https://mrfood225.000webhostapp.com/php/Insert/updateTotalPrice.php';

const selectOrderDetails ='https://mrfood225.000webhostapp.com/php/select/selectOrderDetaials.php';

const updateCashier='https://mrfood225.000webhostapp.com/php/Users/UpdateCasher.php';

const orderCashierHistory='https://mrfood225.000webhostapp.com/php/Users/OrderCasherHistory.php';

const orderHistory =`https://mrfood225.000webhostapp.com/php/Users/OrderHistory.php?mangerId=`;

const UpdateChef = 'https://mrfood225.000webhostapp.com/php/Users/UpdateChef.php';

const updateItems='https://mrfood225.000webhostapp.com/php/updateItems.php';

const updateSubItems='https://mrfood225.000webhostapp.com/php/updateSubItems.php';

const updateChef='https://mrfood225.000webhostapp.com/php/Users/UpdateChef.php';

const orderChefHistory=`https://mrfood225.000webhostapp.com/php/Users/OrderChefHistory.php?chefId=`;

const orderManger=`https://mrfood225.000webhostapp.com/php/Users/OrderManger.php?mangerId=`;

const QrCodeTable='https://mrfood225.000webhostapp.com/php/Users/QrCode.php';

const selectOrderId='https://mrfood225.000webhostapp.com/php/select/selectOrderId.php';

const statisticsSub='https://mrfood225.000webhostapp.com/php/statistics/test.php';

const statisticsGraph = 'https://mrfood225.000webhostapp.com/php/statistics/most.php';

const statisticsPercantage = 'https://mrfood225.000webhostapp.com/php/statistics/CountSubItems.php';

const  statisticsCount = 'https://mrfood225.000webhostapp.com/php/statistics/Count.php';

export {mainMenu, secondList,subItem , images , insertMainMenu ,
    insertSubItems, insertItems,selectedRole ,insertUsers ,selectedUsers,
    selectchef,insertTables,selectTables,deleteSecond,deleteThird,insertOrderDetails,LoginTables,insertMainOrder,updateTotaleprice,
    LoginUser,chefOrder,OrderCashier,updateOrderStatusChef,updateStatus,selectOrderDetails,updateCashier,orderHistory
    ,UpdateChef,updateItems,updateSubItems,updateChef ,orderChefHistory,orderCashierHistory,orderManger,selectManger,QrCodeTable,selectOrderId
    ,statisticsSub,statisticsGraph,statisticsPercantage,statisticsCount
};


