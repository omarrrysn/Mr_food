
import WelcomeImage from "./image/WelcomeImage.jpg";
import AboutImage from "./image/AboutImage.jpeg";
import Logo from "./image/Logo.png";
import CircleHomeImage from './image/Circlefood.png';
import BackgroundImage1 from './image/Blackbackground.jpg';
import Logo1 from './image/Logo1.png';

const images = {
    WelcomeImage,
    AboutImage,
    Logo,
    CircleHomeImage,
    BackgroundImage1,
    Logo1
};

export default images;
