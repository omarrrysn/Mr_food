import React from 'react'
import Layout from "../../compounent/layout/layout";


const PageNotFound = () => {
  return (
  
      <h1 style={{color:"white" ,display:"flex" ,justifyContent:"center",textAlign:"center",padding:"50px"}}>
        PageNotFound
        </h1> 

  )
}
export default PageNotFound;