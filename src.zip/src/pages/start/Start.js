import React from 'react'
import { useEffect } from 'react';
import images from '../../constants/images'
import './Start.css'
const Start = () => {
 

  return (
    <div className='mainlogo' >
      <img src={images.Logo1} className='animation center'/>
    </div>
  );
};


export default Start
